"""
main.py — FastAPI app exposing the AI Recruiter Copilot pipeline.

Run locally:
    pip install -r requirements.txt
    export ANTHROPIC_API_KEY=sk-ant-...
    uvicorn main:app --reload --port 8000

Then POST to http://localhost:8000/rank with a body like the contents
of sample_data.json. This is also the endpoint the frontend's `backend/`
proxy mode should point at if you deploy the prototype outside Claude.ai
(see the README for wiring instructions).
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from agents import RecruiterCopilotPipeline

app = FastAPI(title="AI Recruiter Copilot API", version="0.1.0")

# Loosened for hackathon demo purposes — tighten allow_origins before any
# real deployment.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

pipeline = RecruiterCopilotPipeline()


class Candidate(BaseModel):
    id: str
    name: str
    profile: str


class RankRequest(BaseModel):
    job_description: str
    candidates: list[Candidate]


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/rank")
def rank(request: RankRequest):
    try:
        result = pipeline.run(
            raw_jd_text=request.job_description,
            candidates=[c.model_dump() for c in request.candidates],
        )
        return result
    except Exception as exc:  # noqa: BLE001 — surfaced directly for a hackathon demo
        raise HTTPException(status_code=500, detail=str(exc)) from exc
