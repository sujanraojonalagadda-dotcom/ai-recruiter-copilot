"""
agents.py — AI Recruiter Copilot agent definitions.

Three agent classes, each a thin, well-defined wrapper around a single
Claude API call. Kept deliberately simple for a hackathon prototype:
each agent has one job, one prompt, and one structured output contract.

JDParserAgent        -> structured requirements from a raw JD
CandidateRetriever    -> narrows a large pool with embeddings (stubbed
                         here with a lightweight lexical scorer so the
                         prototype runs with zero external services;
                         swap in a real embedding model / vector DB for
                         production, see README)
EvaluatorAgent         -> scores + ranks + explains each candidate in
                         the narrowed pool (combines the Ranking and
                         Explainability roles from the architecture
                         diagram into one structured call, for latency)
"""

import json
import os
import re
from dataclasses import dataclass, field

import anthropic

MODEL = "claude-sonnet-4-6"

client = anthropic.Anthropic(
    # Reads ANTHROPIC_API_KEY from the environment by default.
    api_key=os.environ.get("ANTHROPIC_API_KEY"),
)


def _extract_json(raw_text: str):
    """Strip optional markdown fences and parse the model's JSON output."""
    cleaned = re.sub(r"^```json\s*|^```\s*|```$", "", raw_text.strip(), flags=re.MULTILINE).strip()
    return json.loads(cleaned)


@dataclass
class JDParserAgent:
    """Turns a raw, possibly informal job description into structured fields."""

    system_prompt: str = field(default=(
        "You are the JD Parser Agent inside an AI recruiting copilot built for "
        "India's non-metro hiring market. Extract structured hiring requirements "
        "from raw, often informal job descriptions (text or transcribed voice "
        "notes, sometimes mixing Hindi and English). Respond with ONLY valid "
        "JSON, no markdown fences, no commentary. Schema: "
        '{"role": string, "must_have_skills": string[], "nice_to_have_skills": '
        'string[], "experience_level": string, "location": string, '
        '"language_requirements": string[], "other_requirements": string[]}'
    ))

    def run(self, raw_jd_text: str) -> dict:
        message = client.messages.create(
            model=MODEL,
            max_tokens=1024,
            system=self.system_prompt,
            messages=[{"role": "user", "content": raw_jd_text}],
        )
        raw_text = "".join(block.text for block in message.content if block.type == "text")
        return _extract_json(raw_text)


@dataclass
class CandidateRetriever:
    """
    Narrows a large candidate pool to the top-N most plausible matches
    before the (more expensive) reasoning agent runs.

    This stub uses simple lexical overlap so the prototype has no
    external dependencies. In production, replace `score()` with cosine
    similarity over multilingual sentence embeddings (e.g. an
    IndicBERT/LaBSE-class model) stored in a vector DB such as FAISS or
    Pinecone — see README "Productionizing" section.
    """

    top_n: int = 25

    def score(self, jd: dict, profile_text: str) -> float:
        keywords = set()
        for field_name in ("must_have_skills", "nice_to_have_skills", "other_requirements"):
            for phrase in jd.get(field_name, []) or []:
                keywords.update(phrase.lower().split())
        profile_words = set(profile_text.lower().split())
        if not keywords:
            return 0.0
        return len(keywords & profile_words) / len(keywords)

    def run(self, jd: dict, candidates: list[dict]) -> list[dict]:
        scored = sorted(candidates, key=lambda c: self.score(jd, c["profile"]), reverse=True)
        return scored[: self.top_n]


@dataclass
class EvaluatorAgent:
    """
    Reasons about each candidate's real fit (not keyword overlap),
    produces a composite score, and an evidence-backed justification.
    Combines the Ranking Agent and Explainability Agent roles from the
    architecture diagram into a single structured call.
    """

    system_prompt: str = field(default=(
        "You are the Candidate Evaluator, Ranking, and Explainability agents "
        "inside an AI recruiting copilot for India's non-metro hiring market. "
        "You will receive a structured job description and a list of candidate "
        "profiles written in informal, real-world language (not polished "
        "resumes). For EACH candidate: reason about their REAL skills and fit, "
        "including implicit skills not stated as keywords (for example, "
        "\"managed my own shop's cash counter daily\" implies cash-handling and "
        "customer-service experience even though the word \"sales\" never "
        "appears). Do not reward a candidate simply for repeating JD keywords. "
        "Score three dimensions from 0-100: skill_fit_score, experience_score, "
        "practical_fit_score (location/language/transport constraints). "
        "Compute composite_score as the nearest integer to "
        "0.5*skill_fit_score + 0.3*experience_score + 0.2*practical_fit_score. "
        "Write a short justification (max 2 sentences) and an evidence_quote "
        "(under 12 words, copied verbatim from that candidate's profile). "
        "Respond with ONLY a valid JSON array, no markdown fences, no "
        "commentary. Schema per item: {\"id\": string, \"skill_fit_score\": "
        "number, \"experience_score\": number, \"practical_fit_score\": number, "
        "\"composite_score\": number, \"justification\": string, "
        "\"evidence_quote\": string}"
    ))

    def run(self, jd: dict, candidates: list[dict]) -> list[dict]:
        payload = json.dumps({
            "job_description": jd,
            "candidates": [{"id": c["id"], "name": c["name"], "profile": c["profile"]} for c in candidates],
        })
        message = client.messages.create(
            model=MODEL,
            max_tokens=3000,
            system=self.system_prompt,
            messages=[{"role": "user", "content": payload}],
        )
        raw_text = "".join(block.text for block in message.content if block.type == "text")
        results = _extract_json(raw_text)
        return sorted(results, key=lambda r: r["composite_score"], reverse=True)


class RecruiterCopilotPipeline:
    """Orchestrates the full JD -> ranked shortlist flow."""

    def __init__(self):
        self.jd_parser = JDParserAgent()
        self.retriever = CandidateRetriever()
        self.evaluator = EvaluatorAgent()

    def run(self, raw_jd_text: str, candidates: list[dict]) -> dict:
        parsed_jd = self.jd_parser.run(raw_jd_text)
        narrowed = self.retriever.run(parsed_jd, candidates)
        ranked = self.evaluator.run(parsed_jd, narrowed)
        name_by_id = {c["id"]: c["name"] for c in candidates}
        for r in ranked:
            r["name"] = name_by_id.get(r["id"], r["id"])
        return {"job_description": parsed_jd, "ranked_candidates": ranked}
